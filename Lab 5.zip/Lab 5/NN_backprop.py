import pandas
import math
import numpy as np
train_data=pandas.read_csv("training.csv")
train_x=train_data.iloc[:,:-1]
layers_dims=[3,2,1]
inputs=[0,1,2]
Z=[]
A=[]

def initialize_parameters(layers_details):
    parameters={}
    TotalLayers=len(layers_details)
    for i in range(1,TotalLayers):
        parameters['W' + str(i)] = np.random.randn(layers_details[i],layers_details[i-1])
        parameters['b' + str(i)] = np.zeros((layers_details[i],1))
    return parameters

def calculate_affine(inputs,w,b):
    # print(w.transpose().shape)
    # print(inputs.shape)
    z=np.dot(w.transpose(),inputs)+b
    return z;
def sigmoid(x):
    return (1+math.exp(-x))

def ForwardLayer(inputs,w,b):
    z=calculate_affine(inputs,w,b)
    print("z+",z)
    # Z.append(z)
    # A.append(sigmoid(z))

def Layer_Model(L,inputs,parameter):
    for i in range(L):
        ForwardLayer(inputs,parameter['W' + str(i+1)],parameter['b' + str(i+1)])



parameters=initialize_parameters(layers_dims)
print(parameters['W1'][0])
# Layer_Model(1,inputs,parameters)
# print(Z)
# print(A)
print(parameters)
# print(parameters)
# affine=calculate_affine(train_data,parameters["W1"],parameters["b1"])
# print(affine)
