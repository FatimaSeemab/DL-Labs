import pandas as pd
drugs=pd.read_csv("drug200.csv")
print("Name of Variables of Drugs Datasets")
print(drugs.columns)
print("Summary of drugs datasets")
print(drugs.info)
boxplot = drugs.boxplot(column=["Age", "Sex", "BP","Cholesterol","Na_to_K"])